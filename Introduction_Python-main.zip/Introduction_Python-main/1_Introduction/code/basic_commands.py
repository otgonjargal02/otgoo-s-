# Sample code ## Github
# Ctrl + Shift + P
# print("Test")


# print('Testing 2') # it is an example
a = 15
print('a is:',a)
# 5+3
# 7+9
# 9+8
# 11-6
# # 9/10/2023 - 3:40pm


# # it is also an example
# print('a is: {}'.format(a))
# b = 25
# print('a is: {} and b is {}'.format(a,b))

# # Basic operators
# 1+2 # add
# 5-9 # subtract
# 5*5 # multiply
# 5/8 # divide
# 5**2 # power ^^^
# 5**(1/2) # power np.sqrt(5)

# # # boolean
# my_condition0 = True 
# my_condition1 = False

# # print(my_condition1)

# # # string variable
# c = 'hello world 12 58'
# cc = "world"

# #c + cc + 5.5
# c + cc + "5.5"
# num = 5.5
# c + cc + str(num)
# c + " " + cc + " " + str(5.5)


# input("text bichij bolno") 
m = input("Enter a number: ") 
print("You entered: " + m + '. Done!')

"a"+"5"
a = "25"
int(a)+5
float(a)+5