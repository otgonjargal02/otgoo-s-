# Python Program to calculate the square root ### local ### remote

print("Hello Py4Econ!")

# To take the input from the user
# num = float(input('Enter a number: '))
num = float(input('Enter a number that you want a square root of: '))

num_sqrt = num ** 0.5 

print('The the square root of ' + str(num) + ' is ' + str(num_sqrt) + '.')

## end
## Batorgil testing ##