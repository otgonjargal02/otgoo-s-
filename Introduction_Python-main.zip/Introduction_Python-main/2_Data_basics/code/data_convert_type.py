int
float
list
tuple
dict

s = 'geeks'
c = tuple(s)
c = set(s)
c = list(s)

tup = (('a', 1) ,('f', 2), ('g', 3))
c = dict(tup)

int("15") 
float("15")
str(15)

# error
"string" + 5