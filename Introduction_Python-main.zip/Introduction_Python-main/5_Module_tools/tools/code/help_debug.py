def func(input):
    output = 1/(input-10) 
    return output